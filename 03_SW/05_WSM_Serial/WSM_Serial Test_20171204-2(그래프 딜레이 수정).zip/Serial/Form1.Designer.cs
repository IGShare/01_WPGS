﻿namespace Serial
{
    partial class WSM_Serial
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Chart_X = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Port_Scan_btn = new System.Windows.Forms.Button();
            this.btnPortClose = new System.Windows.Forms.Button();
            this.lbStatus = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbStopBits = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbParity = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbDataBits = new System.Windows.Forms.ComboBox();
            this.BaudRate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOpen = new System.Windows.Forms.Button();
            this.cmbBRate = new System.Windows.Forms.ComboBox();
            this.cmbPort = new System.Windows.Forms.ComboBox();
            this.SP = new System.IO.Ports.SerialPort(this.components);
            this.WText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Chart_Y = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Chart_total = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Start_button = new System.Windows.Forms.Button();
            this.Stop_button = new System.Windows.Forms.Button();
            this.Chart_Z = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartXY = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartYZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartXZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_X)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_Z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartXY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartYZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartXZ)).BeginInit();
            this.SuspendLayout();
            // 
            // Chart_X
            // 
            chartArea1.Name = "ChartArea1";
            this.Chart_X.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.Chart_X.Legends.Add(legend1);
            this.Chart_X.Location = new System.Drawing.Point(12, 12);
            this.Chart_X.Name = "Chart_X";
            this.Chart_X.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Color = System.Drawing.Color.OrangeRed;
            series1.Legend = "Legend1";
            series1.Name = "X-axis";
            this.Chart_X.Series.Add(series1);
            this.Chart_X.Size = new System.Drawing.Size(695, 133);
            this.Chart_X.TabIndex = 0;
            this.Chart_X.Text = "EMG_Chart1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Port_Scan_btn);
            this.groupBox1.Controls.Add(this.btnPortClose);
            this.groupBox1.Controls.Add(this.lbStatus);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbStopBits);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cmbParity);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmbDataBits);
            this.groupBox1.Controls.Add(this.BaudRate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnOpen);
            this.groupBox1.Controls.Add(this.cmbBRate);
            this.groupBox1.Controls.Add(this.cmbPort);
            this.groupBox1.Location = new System.Drawing.Point(12, 563);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 179);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // Port_Scan_btn
            // 
            this.Port_Scan_btn.ForeColor = System.Drawing.Color.Black;
            this.Port_Scan_btn.Location = new System.Drawing.Point(10, 13);
            this.Port_Scan_btn.Name = "Port_Scan_btn";
            this.Port_Scan_btn.Size = new System.Drawing.Size(102, 23);
            this.Port_Scan_btn.TabIndex = 14;
            this.Port_Scan_btn.Text = "Port Scan";
            this.Port_Scan_btn.UseVisualStyleBackColor = true;
            this.Port_Scan_btn.Click += new System.EventHandler(this.Port_Scan_btn_Click);
            // 
            // btnPortClose
            // 
            this.btnPortClose.BackColor = System.Drawing.Color.Yellow;
            this.btnPortClose.ForeColor = System.Drawing.Color.Black;
            this.btnPortClose.Location = new System.Drawing.Point(335, 95);
            this.btnPortClose.Name = "btnPortClose";
            this.btnPortClose.Size = new System.Drawing.Size(106, 27);
            this.btnPortClose.TabIndex = 13;
            this.btnPortClose.Text = "Port Close";
            this.btnPortClose.UseVisualStyleBackColor = false;
            this.btnPortClose.Visible = false;
            this.btnPortClose.Click += new System.EventHandler(this.btnPortClose_Click);
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbStatus.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbStatus.ForeColor = System.Drawing.Color.Yellow;
            this.lbStatus.Location = new System.Drawing.Point(8, 150);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(105, 21);
            this.lbStatus.TabIndex = 12;
            this.lbStatus.Text = "Not Connect";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "State";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(221, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 14);
            this.label5.TabIndex = 10;
            this.label5.Text = "Stop Bits";
            // 
            // cmbStopBits
            // 
            this.cmbStopBits.FormattingEnabled = true;
            this.cmbStopBits.Items.AddRange(new object[] {
            "NONE",
            "1",
            "1.5",
            "2"});
            this.cmbStopBits.Location = new System.Drawing.Point(224, 55);
            this.cmbStopBits.Name = "cmbStopBits";
            this.cmbStopBits.Size = new System.Drawing.Size(100, 22);
            this.cmbStopBits.TabIndex = 9;
            this.cmbStopBits.Text = "1";
            this.cmbStopBits.SelectedIndexChanged += new System.EventHandler(this.cmbStopBits_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(115, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 14);
            this.label4.TabIndex = 8;
            this.label4.Text = "Parity";
            // 
            // cmbParity
            // 
            this.cmbParity.FormattingEnabled = true;
            this.cmbParity.Items.AddRange(new object[] {
            "EVEN",
            "MARK",
            "NONE",
            "ODD",
            "SPACE"});
            this.cmbParity.Location = new System.Drawing.Point(118, 102);
            this.cmbParity.Name = "cmbParity";
            this.cmbParity.Size = new System.Drawing.Size(100, 22);
            this.cmbParity.TabIndex = 7;
            this.cmbParity.Text = "NONE";
            this.cmbParity.SelectedIndexChanged += new System.EventHandler(this.cmbParity_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(115, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 14);
            this.label3.TabIndex = 6;
            this.label3.Text = "Data bits";
            // 
            // cmbDataBits
            // 
            this.cmbDataBits.FormattingEnabled = true;
            this.cmbDataBits.Items.AddRange(new object[] {
            "8 bits",
            "7 bits"});
            this.cmbDataBits.Location = new System.Drawing.Point(118, 55);
            this.cmbDataBits.Name = "cmbDataBits";
            this.cmbDataBits.Size = new System.Drawing.Size(100, 22);
            this.cmbDataBits.TabIndex = 5;
            this.cmbDataBits.Text = "8 bits";
            this.cmbDataBits.SelectedIndexChanged += new System.EventHandler(this.cmbDataBits_SelectedIndexChanged);
            // 
            // BaudRate
            // 
            this.BaudRate.AutoSize = true;
            this.BaudRate.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BaudRate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BaudRate.Location = new System.Drawing.Point(7, 83);
            this.BaudRate.Name = "BaudRate";
            this.BaudRate.Size = new System.Drawing.Size(74, 14);
            this.BaudRate.TabIndex = 4;
            this.BaudRate.Text = "Baud Rate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 14);
            this.label1.TabIndex = 3;
            this.label1.Text = "COM Port";
            // 
            // btnOpen
            // 
            this.btnOpen.BackColor = System.Drawing.Color.Yellow;
            this.btnOpen.ForeColor = System.Drawing.Color.Black;
            this.btnOpen.Location = new System.Drawing.Point(335, 55);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(106, 27);
            this.btnOpen.TabIndex = 2;
            this.btnOpen.Text = "Port Open";
            this.btnOpen.UseVisualStyleBackColor = false;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // cmbBRate
            // 
            this.cmbBRate.FormattingEnabled = true;
            this.cmbBRate.Items.AddRange(new object[] {
            "9600 bps",
            "14400 bps",
            "19200 bps",
            "38400 bps",
            "57600 bps",
            "115200 bps"});
            this.cmbBRate.Location = new System.Drawing.Point(12, 101);
            this.cmbBRate.Name = "cmbBRate";
            this.cmbBRate.Size = new System.Drawing.Size(100, 22);
            this.cmbBRate.TabIndex = 1;
            this.cmbBRate.Text = "38400 bps";
            this.cmbBRate.SelectedIndexChanged += new System.EventHandler(this.cmbBRate_SelectedIndexChanged);
            // 
            // cmbPort
            // 
            this.cmbPort.FormattingEnabled = true;
            this.cmbPort.Location = new System.Drawing.Point(12, 55);
            this.cmbPort.Name = "cmbPort";
            this.cmbPort.Size = new System.Drawing.Size(100, 22);
            this.cmbPort.TabIndex = 0;
            this.cmbPort.SelectedIndexChanged += new System.EventHandler(this.cmbPort_SelectedIndexChanged);
            // 
            // SP
            // 
            this.SP.ErrorReceived += new System.IO.Ports.SerialErrorReceivedEventHandler(this.SP_ErrorReceived);
            this.SP.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SP_DataReceived);
            // 
            // WText
            // 
            this.WText.Location = new System.Drawing.Point(468, 596);
            this.WText.Multiline = true;
            this.WText.Name = "WText";
            this.WText.Size = new System.Drawing.Size(239, 83);
            this.WText.TabIndex = 17;
            this.WText.TextChanged += new System.EventHandler(this.WText_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(468, 568);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = "Input";
            // 
            // Chart_Y
            // 
            chartArea2.Name = "ChartArea1";
            this.Chart_Y.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.Chart_Y.Legends.Add(legend2);
            this.Chart_Y.Location = new System.Drawing.Point(12, 150);
            this.Chart_Y.Name = "Chart_Y";
            this.Chart_Y.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.Green;
            series2.Legend = "Legend1";
            series2.Name = "Y-axis";
            this.Chart_Y.Series.Add(series2);
            this.Chart_Y.Size = new System.Drawing.Size(695, 129);
            this.Chart_Y.TabIndex = 20;
            this.Chart_Y.Text = "EMG_Chart2";
            // 
            // Chart_total
            // 
            chartArea3.Name = "ChartArea1";
            this.Chart_total.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.Chart_total.Legends.Add(legend3);
            this.Chart_total.Location = new System.Drawing.Point(12, 424);
            this.Chart_total.Name = "Chart_total";
            this.Chart_total.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Color = System.Drawing.Color.OrangeRed;
            series3.Legend = "Legend1";
            series3.Name = "X-axis";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Color = System.Drawing.Color.Green;
            series4.Legend = "Legend1";
            series4.Name = "Y-axis";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Color = System.Drawing.Color.Blue;
            series5.Legend = "Legend1";
            series5.Name = "Z-axis";
            this.Chart_total.Series.Add(series3);
            this.Chart_total.Series.Add(series4);
            this.Chart_total.Series.Add(series5);
            this.Chart_total.Size = new System.Drawing.Size(695, 133);
            this.Chart_total.TabIndex = 21;
            this.Chart_total.Text = "Accel_Z_Chart";
            // 
            // Start_button
            // 
            this.Start_button.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start_button.ForeColor = System.Drawing.Color.Black;
            this.Start_button.Location = new System.Drawing.Point(468, 685);
            this.Start_button.Name = "Start_button";
            this.Start_button.Size = new System.Drawing.Size(57, 49);
            this.Start_button.TabIndex = 1;
            this.Start_button.Text = "Start";
            this.Start_button.UseVisualStyleBackColor = true;
            this.Start_button.Click += new System.EventHandler(this.Start_button_Click);
            // 
            // Stop_button
            // 
            this.Stop_button.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stop_button.ForeColor = System.Drawing.Color.Black;
            this.Stop_button.Location = new System.Drawing.Point(531, 685);
            this.Stop_button.Name = "Stop_button";
            this.Stop_button.Size = new System.Drawing.Size(57, 49);
            this.Stop_button.TabIndex = 2;
            this.Stop_button.Text = "Stop";
            this.Stop_button.UseVisualStyleBackColor = true;
            this.Stop_button.Click += new System.EventHandler(this.Stop_button_Click);
            // 
            // Chart_Z
            // 
            chartArea4.Name = "ChartArea1";
            this.Chart_Z.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.Chart_Z.Legends.Add(legend4);
            this.Chart_Z.Location = new System.Drawing.Point(12, 285);
            this.Chart_Z.Name = "Chart_Z";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.Color = System.Drawing.Color.Blue;
            series6.Legend = "Legend1";
            series6.Name = "Z-axis";
            this.Chart_Z.Series.Add(series6);
            this.Chart_Z.Size = new System.Drawing.Size(695, 133);
            this.Chart_Z.TabIndex = 41;
            this.Chart_Z.Text = "Accel_X_Chart";
            // 
            // chartXY
            // 
            chartArea5.Name = "ChartArea1";
            this.chartXY.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chartXY.Legends.Add(legend5);
            this.chartXY.Location = new System.Drawing.Point(713, 12);
            this.chartXY.Name = "chartXY";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series7.Legend = "Legend1";
            series7.MarkerSize = 3;
            series7.Name = "X-Y Plane";
            this.chartXY.Series.Add(series7);
            this.chartXY.Size = new System.Drawing.Size(377, 231);
            this.chartXY.TabIndex = 42;
            this.chartXY.Text = "chartXY";
            // 
            // chartYZ
            // 
            chartArea6.Name = "ChartArea1";
            this.chartYZ.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chartYZ.Legends.Add(legend6);
            this.chartYZ.Location = new System.Drawing.Point(713, 249);
            this.chartYZ.Name = "chartYZ";
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series8.Legend = "Legend1";
            series8.MarkerSize = 3;
            series8.Name = "Y-Z Plane";
            this.chartYZ.Series.Add(series8);
            this.chartYZ.Size = new System.Drawing.Size(377, 231);
            this.chartYZ.TabIndex = 43;
            this.chartYZ.Text = "chartYZ";
            // 
            // chartXZ
            // 
            chartArea7.Name = "ChartArea1";
            this.chartXZ.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.chartXZ.Legends.Add(legend7);
            this.chartXZ.Location = new System.Drawing.Point(713, 486);
            this.chartXZ.Name = "chartXZ";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series9.Legend = "Legend1";
            series9.MarkerSize = 3;
            series9.Name = "X-Z Plane";
            this.chartXZ.Series.Add(series9);
            this.chartXZ.Size = new System.Drawing.Size(377, 231);
            this.chartXZ.TabIndex = 44;
            this.chartXZ.Text = "chartXZ";
            // 
            // WSM_Serial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1104, 761);
            this.Controls.Add(this.chartXZ);
            this.Controls.Add(this.chartYZ);
            this.Controls.Add(this.chartXY);
            this.Controls.Add(this.Chart_Z);
            this.Controls.Add(this.Chart_total);
            this.Controls.Add(this.Chart_Y);
            this.Controls.Add(this.Stop_button);
            this.Controls.Add(this.Start_button);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.WText);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Chart_X);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1120, 800);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1120, 800);
            this.Name = "WSM_Serial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WSM_Serial";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Chart_X)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chart_Z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartXY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartYZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartXZ)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbPort;
        private System.Windows.Forms.ComboBox cmbBRate;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label BaudRate;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbStopBits;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbParity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbDataBits;
        private System.IO.Ports.SerialPort SP;
        private System.Windows.Forms.Button btnPortClose;
        private System.Windows.Forms.TextBox WText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart_X;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart_Y;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart_total;
        private System.Windows.Forms.Button Start_button;
        private System.Windows.Forms.Button Stop_button;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart_Z;
        private System.Windows.Forms.Button Port_Scan_btn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartXY;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartYZ;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartXZ;
    }
}

