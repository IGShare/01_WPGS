﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Collections;
using System.Diagnostics;
using DWORD = System.UInt16;
using System.Windows.Forms.DataVisualization.Charting; 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * 채널 1,2 (EMG) =>  que[0],que[1],Mutex[1] => k[0] => chart1       ( 왼쪽 아래의 그래프로 EMG 신호의 세기를 받고 있다. )
 * 채널 5,6 (Y축) =>        ,que[2],Mutex[2] => k[1] => chart2       ( 오른쪽 가운데 그래프 )
 * 채널 3,4 (Z축) =>        ,que[3],Mutex[3] => k[2] => chart3       ( 오른쪽 아래 그래프 )
 * 채널 0,7 (X축) =>        ,que[4],Mutex[4] => k[3] => chart4       ( 오른쪽 위 그래프 )
 */

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
namespace Serial
{

    delegate void input(int var);
    public partial class WSM_Serial : Form
    {
        //------------------------------------------------------------------------------------------
        Mutex[] mutex = new Mutex[4];//뮤텍스 선언             
        LinkedList<double>[] LLT = new LinkedList<double>[4]; // 값을 리스트에 넣는 이유는 그냥 데이터를 넣으면 쓰레드가 도는 동안 데이터를 잃을수 있기 떄문
        int InitFlag = 0;           // 초기 데이터 5개 버리기. 혹시 모를 에러를 방지하기 위함.
        double cnt = 0;

        double test_old= -32000;

        //------------------------------------------------------------------------------------------
        System.Windows.Forms.Timer timer =
            new System.Windows.Forms.Timer();
        //-------------------------------------------------------------
        public WSM_Serial()
        {
            InitializeComponent();
            for (int i = 0; i < 4; i++)  //    mutex,LLT 초기화!!
            {
                mutex[i] = new Mutex();
                LLT[i] = new LinkedList<double>();
            }
            
            //Port
            cmbPort.BeginUpdate();
            foreach (string comport in SerialPort.GetPortNames())
            {
                cmbPort.Items.Add(comport);
            }
            cmbPort.EndUpdate();

            //SerialPort 초기 설정
            SP.PortName = "COM4";
            SP.BaudRate = (int)38400;
            SP.DataBits = (int)8;
            SP.Parity = Parity.None;
            SP.StopBits = StopBits.One;
            SP.ReadTimeout = (int)20000;
            SP.WriteTimeout = (int)20000;
            SP.Encoding = Encoding.GetEncoding(28591); //확장아스키 사용

            Chart_X.ChartAreas[0].AxisX.Maximum = 500;
            Chart_X.ChartAreas[0].AxisX.Minimum = 0;

            Chart_Y.ChartAreas[0].AxisX.Maximum = 500;
            Chart_Y.ChartAreas[0].AxisX.Minimum = 0;

            Chart_Z.ChartAreas[0].AxisX.Maximum = 500;
            Chart_Z.ChartAreas[0].AxisX.Minimum = 0;

            Chart_total.ChartAreas[0].AxisX.Maximum = 500;
            Chart_total.ChartAreas[0].AxisX.Minimum = 0;

            chartXY.ChartAreas[0].AxisX.Maximum = 32768;
            chartXY.ChartAreas[0].AxisX.Minimum = -32768;
            chartXY.ChartAreas[0].AxisY.Maximum = 32768;
            chartXY.ChartAreas[0].AxisY.Minimum = -32768;

            chartYZ.ChartAreas[0].AxisX.Maximum = 32768;
            chartYZ.ChartAreas[0].AxisX.Minimum = -32768;
            chartYZ.ChartAreas[0].AxisY.Maximum = 32768;
            chartYZ.ChartAreas[0].AxisY.Minimum = -32768;

            chartXZ.ChartAreas[0].AxisX.Maximum = 32768;
            chartXZ.ChartAreas[0].AxisX.Minimum = -32768;
            chartXZ.ChartAreas[0].AxisY.Maximum = 32768;
            chartXZ.ChartAreas[0].AxisY.Minimum = -32768;

            timer.Interval = 50;
            timer.Tick += new EventHandler(timer_Tick);
        }

        protected void timer_Tick(object sender, EventArgs e)
        {
            int i = 0;
            Series[] k = new Series[9];
            k[0] = Chart_X.Series["X-axis"];
            k[1] = Chart_Y.Series["Y-axis"];
            k[2] = Chart_Z.Series["Z-axis"];

            k[3] = Chart_total.Series["X-axis"];
            k[4] = Chart_total.Series["Y-axis"];
            k[5] = Chart_total.Series["Z-axis"];

            k[6] = chartXY.Series["X-Y Plane"];
            k[7] = chartYZ.Series["Y-Z Plane"];
            k[8] = chartXZ.Series["X-Z Plane"];

            mutex[0].WaitOne();

            if (LLT[0].Count > 1)
            {
                if (Chart_X.ChartAreas[0].AxisY.Minimum > LLT[0].Last())
                {
                    Chart_X.ChartAreas[0].AxisY.Minimum = LLT[0].Last();
                }
                if (Chart_X.ChartAreas[0].AxisY.Maximum < LLT[0].Last())
                {
                    Chart_X.ChartAreas[0].AxisY.Maximum = LLT[0].Last();
                }
            }
            if (LLT[1].Count > 1)
            {
                if (Chart_Y.ChartAreas[0].AxisY.Minimum > LLT[1].Last())
                {
                    Chart_Y.ChartAreas[0].AxisY.Minimum = LLT[1].Last();
                }
                if (Chart_Y.ChartAreas[0].AxisY.Maximum < LLT[1].Last())
                {
                    Chart_Y.ChartAreas[0].AxisY.Maximum = LLT[1].Last();
                }
            }
            if (LLT[2].Count > 1)
            {
                if (Chart_Z.ChartAreas[0].AxisY.Minimum > LLT[2].Last())
                {
                    Chart_Z.ChartAreas[0].AxisY.Minimum = LLT[2].Last();
                }
                if (Chart_Z.ChartAreas[0].AxisY.Maximum < LLT[2].Last())
                {
                    Chart_Z.ChartAreas[0].AxisY.Maximum = LLT[2].Last();
                }
            }

            //Determine the next X value
            double nextX = 1;
            
            //////////////////////////////
            while ((LLT[0].Count > 1) && (LLT[1].Count > 1) && (LLT[2].Count > 1))
            {
                

                if (k[6].Points.Count > 0) k[6].Points[k[6].Points.Count - 1].Color = Color.Red;
                if (k[7].Points.Count > 0) k[7].Points[k[7].Points.Count - 1].Color = Color.Green;
                if (k[8].Points.Count > 0) k[8].Points[k[8].Points.Count - 1].Color = Color.Blue;

                k[6].Points.AddXY(LLT[0].First(), LLT[1].First());  // XY Plane
                k[7].Points.AddXY(LLT[1].First(), LLT[2].First());  // YZ Plane
                k[8].Points.AddXY(LLT[0].First(), LLT[2].First());  // XZ Plane

                k[6].Points[k[6].Points.Count - 1].Color = Color.Black;
                k[7].Points[k[7].Points.Count - 1].Color = Color.Black;
                k[8].Points[k[8].Points.Count - 1].Color = Color.Black;

                for (i = 0; i < 3; i++)
                {
                    if (k[i].Points.Count > 0)
                    {
                        nextX = k[i].Points[k[i].Points.Count - 1].XValue + 1;
                    }
                    k[i].Points.AddXY(nextX, LLT[i].First());   // X Chart, Y Chart, Z Chart
                    k[i + 3].Points.AddXY(nextX, LLT[i].First()); // Total Chart
                    LLT[i].RemoveFirst();

                    //Remove Points on the left side
                    while (k[i].Points.Count > 500)         // X Chart, Y Chart, Z Chart
                    {
                        k[i].Points.RemoveAt(0);
                    }

                    while (k[i + 3].Points.Count > 500)   // Total Chart
                    {
                        k[i + 3].Points.RemoveAt(0);
                    }
                }
                

                while (k[6].Points.Count > 50)   // 누적개수 50개로 한정
                {
                    k[6].Points.RemoveAt(0);
                }
                while (k[7].Points.Count > 50)  // 누적개수 50개로 한정
                {
                    k[7].Points.RemoveAt(0);
                }
                while (k[8].Points.Count > 50)  // 누적개수 50개로 한정
                {
                    k[8].Points.RemoveAt(0);
                }
            }
            
        
            mutex[0].ReleaseMutex();

            if (k[0].Points.Count > 0)
            {
                //Set the Minimum and Maximum values for the X Axis on the Chartz
                double min = k[0].Points[0].XValue;
                Chart_X.ChartAreas[0].AxisX.Minimum = min;
                Chart_X.ChartAreas[0].AxisX.Maximum = min + 500;
            }
            if (k[1].Points.Count > 0)
            {
                //Set the Minimum and Maximum values for the Y Axis on the Chartz
                double min = k[1].Points[0].XValue;
                Chart_Y.ChartAreas[0].AxisX.Minimum = min;
                Chart_Y.ChartAreas[0].AxisX.Maximum = min + 500;
            }
            if (k[2].Points.Count > 0)
            {
                //Set the Minimum and Maximum values for the Z Axis on the Chartz
                double min = k[2].Points[0].XValue;
                Chart_Z.ChartAreas[0].AxisX.Minimum = min;
                Chart_Z.ChartAreas[0].AxisX.Maximum = min + 500;
            }

            if (k[3].Points.Count > 0)
            {
                //Set the Minimum and Maximum values for the Total on the Chartz
                double min = k[3].Points[0].XValue;
                Chart_total.ChartAreas[0].AxisX.Minimum = min;
                Chart_total.ChartAreas[0].AxisX.Maximum = min + 500;
            }
            lbStatus.Text = "수신버퍼갯수 : "+ Convert.ToString(SP.BytesToRead);
            Invalidate();
            Update();
        }
        
        private void SP_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //-----------------------------------------------------------------
            if (SP.IsOpen)
            {
                string str = SP.ReadExisting(); // str[0]에 데이터가 들어있음.  
                string[] Mysplit = new string[] { "\r\n" };
                string[] str2 = str.Split(Mysplit,StringSplitOptions.None);

                for (int i = 0; i < str2.Length; i++) {
                    if (str2[i].Length == 9)
                    {
                        int Xaxis, Yaxis, Zaxis;
                        string[] str3 = str2[i].Split(',');

                        if (((str3[0].Length != 3)) || str3[1].Length != 2 || str3[2].Length != 2) { }
                        else
                        {
                            Xaxis = (str3[0][1] << 8) + str3[0][2];
                            if (Xaxis > 32768) Xaxis = Xaxis - 65536;

                            Yaxis = (str3[1][0] << 8) + str3[1][1];
                            if (Yaxis > 32768) Yaxis = Yaxis - 65536;

                            Zaxis = (str3[2][0] << 8) + str3[2][1];
                            if (Zaxis > 32768) Zaxis = Zaxis - 65536;

                            test_old = Xaxis;

                            mutex[0].WaitOne();

                            LLT[0].AddLast(Xaxis); // X-axis
                            LLT[1].AddLast(Yaxis); // Y-axis
                            LLT[2].AddLast(Zaxis); // Z-axis

                            mutex[0].ReleaseMutex();
                        }
                    }
                }
                

                /*/////////////////// ReadLine()이 딜레이로 딜레이가 생겨서 변경해야함..~
                string str = SP.ReadLine(); // str[0]에 데이터가 들어있음.  

                if (InitFlag > 5)
                {   // 초기 데이터 5개 버리기. 혹시 모를 에러를 방지하기 위함.
                    str = str.Trim().Replace("\n", "");
                    str = str.Trim().Replace("\r", "");
                    //str = str.Trim().Replace("\0", "");

                    string[] str2 = str.Split(',');
                    if (str2.Length == 3)
                    {
                        int Xaxis, Yaxis, Zaxis;

                        if (((str2[0].Length != 3)) || str2[1].Length != 2 || str2[2].Length != 2) { }
                        else {
                            Xaxis = (str2[0][1] << 8) + str2[0][2];
                            if (Xaxis > 32768) Xaxis = Xaxis - 65536;
                            
                            Yaxis = (str2[1][0] << 8) + str2[1][1];
                            if (Yaxis > 32768) Yaxis = Yaxis - 65536;

                            Zaxis = (str2[2][0] << 8) + str2[2][1];
                            if (Zaxis > 32768) Zaxis = Zaxis - 65536;

                            test_old = Xaxis;

                            mutex[0].WaitOne();

                            LLT[0].AddLast(Xaxis); // X-axis
                            LLT[1].AddLast(Yaxis); // Y-axis
                            LLT[2].AddLast(Zaxis); // Z-axis

                            mutex[0].ReleaseMutex();
                        }
                    }
                }
                else
                {  // 초기 데이터 5개 버리기. 혹시 모를 에러를 방지하기 위함.
                    InitFlag++;
                }
                *////////////////////////////~ReadLine()이 딜레이로 딜레이가 생겨서 변경해야함



                //////<<<<<< 100,200,300 형식>>>>>>//////
                /*
                string str;
                str = SP.ReadLine(); // str[0]에 데이터가 들어있음.  

                if (InitFlag > 5){  // 초기 데이터 5개 버리기. 혹시 모를 에러를 방지하기 위함.
                    str = str.Trim().Replace("\n", "");
                    str = str.Trim().Replace("\r", "");
                    str = str.Trim().Replace("\0", "");

                    string[] str2 = str.Split(',');
                    if (str2.Length == 3)
                    {
                        mutex[0].WaitOne();
                        LLT[0].AddLast(Convert.ToDouble(str2[0])); // X-axis
                        mutex[0].ReleaseMutex();

                        mutex[1].WaitOne();
                        LLT[1].AddLast(Convert.ToDouble(str2[1])); // Y-axis
                        mutex[1].ReleaseMutex();

                        mutex[2].WaitOne();
                        LLT[2].AddLast(Convert.ToDouble(str2[2])); // Z-axis
                        mutex[2].ReleaseMutex();
                    }
                }
                else
                {  // 초기 데이터 5개 버리기. 혹시 모를 에러를 방지하기 위함.
                    InitFlag++;
                }
                */

            }
        }

        

        private void cmbPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            SP.PortName = cmbPort.SelectedItem.ToString();
        }

        private void cmbBRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbBRate.SelectedIndex)
            {
                case 0:
                    SP.BaudRate = (int)9600;
                    break;
                case 1:
                    SP.BaudRate = (int)14400;
                    break;
                case 2:
                    SP.BaudRate = (int)19200;
                    break;
                case 3:
                    SP.BaudRate = (int)38400;
                    break;
                case 4:
                    SP.BaudRate = (int)57600;
                    break;
                case 5:
                    SP.BaudRate = (int)115200;
                    break;
                default:
                    SP.BaudRate = (int)19200;
                    break;
            }
        }

        private void cmbDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbDataBits.SelectedIndex)
            {
                case 0:
                    SP.DataBits = 8;
                    break;
                case 1:
                    SP.DataBits = 7;
                    break;
                default:
                    SP.DataBits = 8;
                    break;
            }
        }

        private void cmbParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbParity.SelectedIndex)
            {
                case 0:
                    SP.Parity = Parity.Even;
                    break;
                case 1:
                    SP.Parity = Parity.Mark;
                    break;
                case 2:
                    SP.Parity = Parity.None;
                    break;
                case 3:
                    SP.Parity = Parity.Odd;
                    break;
                case 4:
                    SP.Parity = Parity.Space;
                    break;
                default:
                    SP.Parity = Parity.None;
                    break;
            }
        }

        private void cmbStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbStopBits.SelectedIndex)
            {
                case 0:
                    //SP.StopBits = StopBits.None;
                    MessageBox.Show("이 값은 지원되지 않습니다");
                    break;
                case 1:
                    SP.StopBits = StopBits.One;
                    break;
                case 2:
                    SP.StopBits = StopBits.OnePointFive;
                    break;
                case 3:
                    SP.StopBits = StopBits.Two;
                    break;
                default:
                    SP.StopBits = StopBits.One;
                    break;
            }
        }
        private void Start_button_Click(object sender, EventArgs e)
        {
            //timer.Start();
            //SP.WriteLine("e0005");
        }

        private void Stop_button_Click(object sender, EventArgs e)
        {
            //timer.Stop();
            //SP.WriteLine("e0006");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            timer.Start();
            SP.Open();
            if (SP.IsOpen)
            {
                btnOpen.Visible = false;
                btnPortClose.Visible = true;
                lbStatus.Text = "Connect";
            }
            else
            {
                lbStatus.ForeColor = Color.Red;
            }
        }
        private void btnPortClose_Click(object sender, EventArgs e)
        {
            timer.Stop();
            if (SP.IsOpen)
            {
                SP.Close();
            }
            lbStatus.Text = "Not Connect";
            btnOpen.Visible = true;
            btnPortClose.Visible = false;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (SP.IsOpen)
            {
                SP.Close();
            }
        }

        private void WText_TextChanged(object sender, EventArgs e)
        {
            if ((WText.Text).IndexOf("\r\n") != -1 && SP.IsOpen)
            {
                SP.WriteLine(WText.Text);
                WText.Text = "";
            }
        }
        
        private void Port_Scan_btn_Click(object sender, EventArgs e)
        {
            cmbPort.BeginUpdate();
            cmbPort.Items.Clear();
            foreach (string comport in SerialPort.GetPortNames())
            {
                cmbPort.Items.Add(comport);
            }
            cmbPort.EndUpdate();
        }

        private void SP_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            double debug = 0;

            debug++;
        }
    }
}
