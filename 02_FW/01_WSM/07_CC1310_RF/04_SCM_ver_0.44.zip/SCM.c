/*
 * Made by - Shin, seckju
 * Made by - Igshare co., Ltd.
 *
 * < History >
 *  < Version 0.40 >
 *  Tx, Rx
 *
 *  < Version 0.41 >
 *  Init SCM version.
 *
 *  < Version 0.42 >
 *  Init SCM version.
 *
 *  < Version 0.43 >
 *  Init SCM version.
 *
 *  < Version 0.44 >
 *  Init SCM version.
*/

/***** Includes *****/
#include <stdlib.h>
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <driverlib/rf_prop_mailbox.h>

/* Board Header files */
#include "Board.h"

#include "RFQueue.h"
#include "smartrf_settings/smartrf_settings.h"

#include <stdlib.h>

static RF_Object rfObject_RX;
static RF_Handle rfHandle_RX;
static RF_CmdHandle rxCmdHndl;

static RF_Object rfObject_TX;
static RF_Handle rfHandle_TX;

/* Pin driver handle */
static PIN_Handle buttonPinHandle;
static PIN_State buttonPinState;

static PIN_Handle pinHandle_TX;
static PIN_Handle pinHandle_RX;

/*
 * Application LED pin configuration table:
 *   - All LEDs board LEDs are off.
 */
static PIN_Handle ledPinHandle_TX;
static PIN_State ledPinState_TX;

static PIN_Handle ledPinHandle_RX;
static PIN_State ledPinState_RX;

static PIN_Handle ledPinHandle_LED3;
static PIN_State ledPinState_LED3;

static PIN_Handle ledPinHandle_LED4;
static PIN_State ledPinState_LED4;

// Button thread..
Task_Params taskParams;
Task_Struct myTask;
Char myTaskStack[512];

PIN_Config pinTable_TX[] =
{
    Board_LED1 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config pinTable_RX[] =
{
    Board_LED2 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config pinTable_LED3[] =
{
    Board_LED3 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config pinTable_LED4[] =
{
    Board_LED4 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config buttonPinTable[] = {
    Board_BUTTON0  | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    Board_BUTTON1  | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    PIN_TERMINATE
};


/***** SJ flag *****/
static uint8_t ModeFlag = 0;

#define SettingMode_RX 0
#define SettingMode_TX 1
#define SensingMode_RX 2
#define SensingMode_TX 3

static uint8_t SCM_ID=0;
static uint8_t WSM_Control_ID=0;
static long WSM_Serial_ID=0;

static uint8_t MySCM_ID=5;
static uint8_t MyWSM_Control_ID=0;
static long MyWSM_Serial_ID=98432;


/***** Defines *****/
#define RX_TASK_STACK_SIZE 1024
#define RX_TASK_PRIORITY   1

#define TX_TASK_STACK_SIZE 1024
#define TX_TASK_PRIORITY   2

/* Packet RX Configuration */
#define DATA_ENTRY_HEADER_SIZE 8  /* Constant header size of a Generic Data Entry */
#define MAX_LENGTH             6 /* Max length byte the radio will accept */
#define NUM_DATA_ENTRIES       2  /* NOTE: Only two data entries supported at the moment */
#define NUM_APPENDED_BYTES     2  /* The Data Entries data field will contain:
                                   * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
                                   * Max 30 payload bytes
                                   * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) */


/* Packet TX Configuration */
#define PAYLOAD_LENGTH      6
#define PACKET_INTERVAL     (uint32_t)(4000000*0.5f) /* Set packet interval to 500ms */


/***** Prototypes *****/
static void txTaskFunction(UArg arg0, UArg arg1);
static void rxTaskFunction(UArg arg0, UArg arg1);
static void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

/***** Variable declarations *****/
static Task_Params rxTaskParams;
Task_Struct rxTask;    /* not static so you can see in ROV */
static uint8_t rxTaskStack[RX_TASK_STACK_SIZE];

static Task_Params txTaskParams;
Task_Struct txTask;    /* not static so you can see in ROV */
static uint8_t txTaskStack[TX_TASK_STACK_SIZE];

static RF_Object rfObject_RX;
static RF_Handle rfHandle_RX;

static RF_Object rfObject_TX;
static RF_Handle rfHandle_TX;

/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is 4 byte aligned (requirement from the RF Core) */
#if defined(__TI_COMPILER_VERSION__)
    #pragma DATA_ALIGN (rxDataEntryBuffer, 4);
        static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                                 MAX_LENGTH,
                                                                 NUM_APPENDED_BYTES)];
#elif defined(__IAR_SYSTEMS_ICC__)
    #pragma data_alignment = 4
        static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                                 MAX_LENGTH,
                                                                 NUM_APPENDED_BYTES)];
#elif defined(__GNUC__)
        static uint8_t rxDataEntryBuffer [RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
            MAX_LENGTH, NUM_APPENDED_BYTES)] __attribute__ ((aligned (4)));
#else
    #error This compiler is not supported.
#endif

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;


static uint8_t packet_RX[MAX_LENGTH + NUM_APPENDED_BYTES - 1]; /* The length byte is stored in a separate variable */

uint32_t time;
static uint8_t packet_TX[PAYLOAD_LENGTH];
static uint16_t seqNumber;

/***** Function definitions *****/
void RxTask_init(PIN_Handle ledPinHandle) {
    pinHandle_RX = ledPinHandle;

    Task_Params_init(&rxTaskParams);
    rxTaskParams.stackSize = RX_TASK_STACK_SIZE;
    rxTaskParams.priority = RX_TASK_PRIORITY;
    rxTaskParams.stack = &rxTaskStack;
    rxTaskParams.arg0 = (UInt)1000000;

    Task_construct(&rxTask, rxTaskFunction, &rxTaskParams, NULL);

}

void TxTask_init(PIN_Handle inPinHandle)
{
    pinHandle_TX = inPinHandle;

    Task_Params_init(&txTaskParams);
    txTaskParams.stackSize = TX_TASK_STACK_SIZE;
    txTaskParams.priority = TX_TASK_PRIORITY;
    txTaskParams.stack = &txTaskStack;
    txTaskParams.arg0 = (UInt)1000000;

    Task_construct(&txTask, txTaskFunction, &txTaskParams, NULL);

}

static void txTaskFunction(UArg arg0, UArg arg1)
{
    uint32_t time;
    RF_Params rfParams;
    RF_Params_init(&rfParams);
    int j = 0;


    RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
    RF_cmdPropTx.pPkt = packet_TX;
    RF_cmdPropTx.startTrigger.triggerType = TRIG_ABSTIME;
    RF_cmdPropTx.startTrigger.pastTrig = 1;
    RF_cmdPropTx.startTime = 0;

    /* Request access to the radio */
    rfHandle_TX = RF_open(&rfObject_TX, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);

    /* Set the frequency */
    RF_postCmd(rfHandle_TX, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);

    /* Get current time */
    time = RF_getCurrentTime();
    for(j = 0 ; j < 1; j++){
        if(ModeFlag == SettingMode_TX){
            packet_TX[0] = 0x00;   // Setting Tx�ϰ� SCM ID�� 5��
            packet_TX[0] = packet_TX[0] | MySCM_ID;   // ������ SCM 5��

            WSM_Serial_ID = 98432;

            packet_TX[1] = WSM_Serial_ID >> 16;   // �޴� WSM��ȣ�� 98432��      0x01(65536),
            packet_TX[2] = WSM_Serial_ID >> 8;   //                      0x80(32768),
            packet_TX[3] = WSM_Serial_ID;       //                      0x80(128)

            WSM_Control_ID = 10;

            packet_TX[4] = WSM_Control_ID;   // Callback���� Serial ID������ Control ID ã�µ�, Callback �������� ã�� ����.
            packet_TX[5] = 0x00;

            /* Set absolute TX time to utilize automatic power management */
            time += PACKET_INTERVAL;
            RF_cmdPropTx.startTime = time;

            /* Send packet */
            RF_EventMask result = RF_runCmd(rfHandle_TX, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, NULL, 0);
            if (!(result & RF_EventLastCmdDone))
            {
                /* Error */
                while(true);
            }

            PIN_setOutputValue(pinHandle_TX, Board_LED1,!PIN_getOutputValue(Board_LED1));
        }
    }

    RF_close(rfHandle_TX);

    ModeFlag = SensingMode_RX;
    RxTask_init(ledPinHandle_RX);
}

static void rxTaskFunction(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);



    if( RFQueue_defineQueue(&dataQueue,
                            rxDataEntryBuffer,
                            sizeof(rxDataEntryBuffer),
                            NUM_DATA_ENTRIES,
                            MAX_LENGTH + NUM_APPENDED_BYTES))
    {
        /* Failed to allocate space for all data entries */
        while(1);
    }
//
    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRx.pQueue = &dataQueue;           /* Set the Data Entity queue for received data */
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  /* Discard ignored packets from Rx queue */
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   /* Discard packets with CRC error from Rx queue */
    RF_cmdPropRx.maxPktLen = MAX_LENGTH;        /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.pktConf.bRepeatOk = 1;
    RF_cmdPropRx.pktConf.bRepeatNok = 1;

    /* Request access to the radio */
    rfHandle_RX = RF_open(&rfObject_RX, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);

    /* Set the frequency */
    RF_postCmd(rfHandle_RX, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);

    /* Enter RX mode and stay forever in RX */
    //rxCmdHndl = RF_runCmd(rfHandle_RX, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &callback, IRQ_RX_ENTRY_DONE);
    rxCmdHndl = RF_postCmd(rfHandle_RX, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &callback, IRQ_RX_ENTRY_DONE);

    while(1){
        if( (ModeFlag%2) == 0 ){}
        else if( (ModeFlag%2) == 1 ){ // TX�� �Ǹ� RX�κе� ��� ����
            RF_cancelCmd(rfHandle_RX,rxCmdHndl,0);
            RF_pendCmd(rfHandle_RX, rxCmdHndl, RF_EventRxEntryDone);
            RF_close(rfHandle_RX);
            TxTask_init(ledPinHandle_TX);
            break;
        }
    }
}

void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if ((e & RF_EventRxEntryDone) && ((ModeFlag %2) == 0))
    {
        /* Toggle pin to indicate RX */
        PIN_setOutputValue(pinHandle_RX, Board_LED2,!PIN_getOutputValue(Board_LED2));

        /* Get current unhandled data entry */
        currentDataEntry = RFQueue_getDataEntry();

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t*)(&currentDataEntry->data);
        packetDataPointer = (uint8_t*)(&currentDataEntry->data + 1);

        /* Copy the payload + the status byte to the packet variable */
        memcpy(packet_RX, packetDataPointer, (packetLength + 1));

        /* < Setting Packet >
                 * 1b -> Setting or Data    ( Setting = 0     , Data = 1    )
                 * 1b -> Rx, Tx direction   ( Rx = 0(SCM->WSM), Tx = 1(WSM->SCM) )
                 * 2b -> empty
                 * 4b -> SCM ID(4b)
                 * 3B -> WSM Serial.ID
                 *  B -> Data
                 *
                 *
        *  < Data Packet >
                 * 1b -> Setting or Data  ( Setting = 0     , Data = 1    )
                 * 1b -> Rx, Tx direction ( Rx = 0(SCM->WSM), Tx = 1(WSM->SCM) )
                 * 2b -> empty
                 * 4b -> SCM ID(4b)
                 * 1B -> WSM Control.ID
                 * 1b -> Battery flag, 7b -> Battery Data
                 * 1b -> Sensor flag,  7b -> Sensor Data
                 */
//SettingThreadHold

        if( (packet_RX[0] & 0x80) == 0x80 ){      // Data Packet
            if( (packet_RX[0] & 0x40) == 0x40 ){  // WSM -> SCM Packet
                PIN_setOutputValue(ledPinHandle_LED3, Board_LED3,!PIN_getOutputValue(Board_LED3));
            }
            else{                               // SCM -> WSM Packet
                // TX�� TX�� ���� ����
            }
        }
        else{                                   // Setting Packet
            if( (packet_RX[0] & 0x40) == 0x40 ){  // WSM -> SCM Packet
                WSM_Serial_ID = 0 ; // WSM �ø��� ��ȣ �ʱ�ȭ
                WSM_Serial_ID += packet_RX[1]<<16;
                WSM_Serial_ID += packet_RX[2]<<8;
                WSM_Serial_ID += packet_RX[3];

                // WSM���� �˻��ϰ�, Control ID ã�� WSM_Control_ID����.
                ModeFlag = SettingMode_TX;

            }
            else{                               // SCM -> WSM Packet
                // TX�� Tx���� ����
            }
        }

        RFQueue_nextEntry();
    }
}

///////////////////////////////////////// Button Interrupt ~ /////////////////////////////////////
void buttonCallbackFxn(PIN_Handle handle, PIN_Id pinId) {
    CPUdelay(8000*50);
    if (!PIN_getInputValue(pinId)) {
        /* Toggle LED based on the button pressed */
        PIN_setOutputValue(ledPinHandle_LED4, Board_LED4,!PIN_getOutputValue(Board_LED4));
        ModeFlag = SettingMode_TX;   // Change the Mode for Tx
    }
}

static void taskFxn(UArg a0, UArg a1)
{
    /* Loop forever */
    buttonPinHandle = PIN_open(&buttonPinState, buttonPinTable);
    if(!buttonPinHandle) {
        System_abort("Error initializing button pins\n");
    }

    if (PIN_registerIntCb(buttonPinHandle, &buttonCallbackFxn) != 0) {  // Button Interrupt -> start buttionCallbackFxn()
        System_abort("Error registering button callback function");
    }
}
///////////////////////////////////////// ~Button Interrupt  /////////////////////////////////////



int main(void)
{
    /* Call board init functions. */
    Board_initGeneral();

    /* Open LED pins */
    ledPinHandle_RX = PIN_open(&ledPinState_RX, pinTable_RX);
    if(!ledPinHandle_RX)
    {
        System_abort("Error initializing board LED pins\n");
    }
    ledPinHandle_TX = PIN_open(&ledPinState_TX, pinTable_TX);
    if(!ledPinHandle_TX)
    {
        System_abort("Error initializing board LED pins\n");
    }
    ledPinHandle_LED3 = PIN_open(&ledPinState_LED3, pinTable_LED3);
    if(!ledPinHandle_LED3)
    {
        System_abort("Error initializing board LED pins TX\n");
    }
    ledPinHandle_LED4 = PIN_open(&ledPinState_LED4, pinTable_LED4);
    if(!ledPinHandle_LED4)
    {
        System_abort("Error initializing board LED pins TX\n");
    }

    // Button Interrupt thread..
    Task_Params_init(&taskParams);
    taskParams.stack = myTaskStack;
    taskParams.stackSize = sizeof(myTaskStack);
    Task_construct(&myTask, taskFxn, &taskParams, NULL);


    //#define SettingMode_RX 0
    //#define SettingMode_TX 1
    //#define SensingMode_RX 2
    //#define SensingMode_TX 3

    /* Initialize task */
    //ModeFlag = 0;
    //RxTask_init(ledPinHandle_RX);

    ModeFlag = SettingMode_TX;
    TxTask_init(ledPinHandle_TX);

    /* Start BIOS */
    BIOS_start();

    return (0);
}
